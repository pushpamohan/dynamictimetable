package dynamicTT;

public class TimeSlot {
	
	private Lecture lecture;

	public Lecture getLecture() {
		return lecture;
	}

	public void setLecture(Lecture lecture) {
		this.lecture = lecture;
	}
}
